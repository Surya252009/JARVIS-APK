# JARVIS Mark VII Android APK project

This project wraps the supplied Gemini Studio HTML file in a simple Android WebView app.

## Build on GitHub
1. Upload the contents of this folder to the root of a GitHub repository.
2. Open **Actions** and select **Build JARVIS APK**.
3. Run workflow (or wait for the push build).
4. Open the successful run and download the **JARVIS-APK** artifact.

The HTML file is at `app/src/main/assets/index.html`.

Note: This creates a basic WebView APK. Browser-only capabilities, remote APIs, microphone access, and smart-home integrations still depend on Android permissions, network access, and the configuration inside the HTML. Do not put private API keys into a public repository.
